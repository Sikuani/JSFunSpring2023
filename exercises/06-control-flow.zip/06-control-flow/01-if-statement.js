const burger = 7.0; // e.g. 
const drink = 1.99; // e.g.

let total = burger;

let isBuyingDrink = true; // e.g.

/**
 * At the "Happy Burger", you have two choices:
 * - A burger ($7.00)
 * - A burger ($7.00) and a drink ($1.99)
 *
 * If "isBuyingDrink" is true, add the cost of "drink" to the "total".
 * If "isBuyingDrink" is false, do not change the cost.
 *
 * This should still work when "burger" and "drink" are equal to different numbers.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let totalCost = total + drink;

function totalCombo () {
  if (isBuyingDrink === true) {
    totalCost = burger + drink
  }

  else {
    totalCost = burger;
  }
}

totalCombo()
console.log(totalCost);
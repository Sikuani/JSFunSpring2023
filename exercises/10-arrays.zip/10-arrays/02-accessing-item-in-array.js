const cars = ["BMW", "Honda", "Civic"]; // Do not change this line

/**
 * Create a variable called "myCar".
 * It should be equal to the first item in the array of cars.
 * Solve this problem without using destructuring.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let myCar = cars[0];

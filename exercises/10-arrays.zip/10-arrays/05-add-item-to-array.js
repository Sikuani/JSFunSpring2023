let languages = ["C++"]; // Do not change this line

/**
 * Add three more computer languages to the languages array.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

languages.push("Python", "Cobol", "Java");

console.log(languages);
/**
 * Create an array called "restaurants". (Do not use var.)
 * It should contain a list of at least three items
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let restaurants = ["Mocha", "Emperator", "Seven79"]

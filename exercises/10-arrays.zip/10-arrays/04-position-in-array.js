let results = [
  // e.g.
  "Aaminata Kamau",
  "Claire O'Hannigan",
  "María Rosales",
  "Jian Hou",
  "Fathima Kaur",
];

/**
 * The array "results" lists runners in the order
 * in which they placed within a race.
 * So, for example, Jian Hou placed 3rd in the example above.
 *
 * Create a variable called "place".
 * It should be equal to whatever place Jian Hou is in.
 *
 * Your answer should still work when the names are in a different order.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let place = results.indexOf("Jian Hou") + 1;
console.log(place);
const str = "bananas"; // e.g.

/**
 * Create a new constant called "strLength". It should be evaluate to the number of characters within the value of "str".
 * @example
 * - If "str" is "bananas", "strLength" should count the number of characters and result in 7.
 * - If "str" is "chocolate", "strLength" should count the number of characters and result in 9.
 * This should still work when "str" is equal to a different value.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

const strLength = str.length;
console.log(strLength);
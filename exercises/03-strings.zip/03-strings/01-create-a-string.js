/**
 * Create a new variable called "myName". It should be equal to your name, which is a string.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let myName = "Manuel";
console.log(myName);
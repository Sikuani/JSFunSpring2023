# HTTP and REST APIs

This is a quiz assignment you will need to complete in Teams. The assignment is called "25 HTTP and REST APIs". I'm using this Github folder to host the images that are used in the assignment.

let answer = "55"; // e.g.

/**
 * You will change the value of "answer" below. Cast (convert) "answer", which is a string, so that it is an integer.
 * This should still work when "answer" is a different numeric value (e.g. "105", "-5", "1.23")
 */

// WRITE YOUR ANSWER BELOW THIS LINE

console.log(parseInt(answer));
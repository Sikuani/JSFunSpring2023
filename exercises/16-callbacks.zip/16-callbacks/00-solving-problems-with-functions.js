/**
 * Return the function's argument. (This problem is to get you used to the new format.)
 * @param {string} personName
 * @returns {string} personName
 */

const returnAnswer = (personName) => {
  // WRITE YOUR ANSWER IN HERE
  return personName;
};

// Uncomment me to test in Quokka
console.log(returnAnswer('Lesley'));

// DO NOT DELETE BELOW. It is for the tests.

export { returnAnswer };

const clothes = {
  hat: "ballcap",
  shirt: "jersey",
  shoes: "cleats",
};

/**
 * Create a variable called "hat".
 * It should be equal to whatever the "hat" property is inside of the "clothes" object.
 * This should still work when "clothes" has different values.
 */

// WRITE YOUR ANSWER BELOW THIS LINE
let hat = clothes.hat;

console.log(hat);
let a = 10; // e.g.
let b = 5; // e.g.

/**
 * Create a new variable called "difference". It should equal the "b" minus "a".
 * This should still work when "a" and "b" are equal to different numbers.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let difference = b - a;
console.log(difference);
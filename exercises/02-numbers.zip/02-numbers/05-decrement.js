let age2 = 90; // e.g.

/**
 * Decrement the variable "age" by 1. (That is, subtract 1).
 * Use the decrement operator to solve this problem.
 * This should still work when "age" is a different number.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

age2 --;
console.log(age2);
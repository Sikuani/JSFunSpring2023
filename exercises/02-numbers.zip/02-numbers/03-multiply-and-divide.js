const ONE_HUNDRED = 100;

/**
 * Create a constant called "percentage".
 * It should equal one number divided by another, and then multiplied by "ONE_HUNDRED".
 */

// WRITE YOUR ANSWER BELOW THIS LINE

let num1 = 20;
let num2 = 10;
const percentage = (num1/num2) * ONE_HUNDRED;

console.log(percentage);

/**
 * Create a constant called "sum".
 * On the right side of the "equals" sign, there should two numbers and a plus sign.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

const sum = 2 + 3
console.log(sum);
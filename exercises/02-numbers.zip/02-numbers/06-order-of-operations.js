/**
 * Without changing the numbers themselves,
 * change the syntax or order of operations so that result equals 800.
 */

// WRITE YOUR ANSWER BELOW THIS LINE

const result = (3 + 5) * 100;
console.log(result);
let error = "Username already exists."; // When the test runs, this could also be an empty string

/**
 * Use short circuiting to solve this problem.
 *
 * Create a variable called "errorMessage".
 * If "error" has a message (in order words, its a string that isn't an empty string),
 * then "errorMessage" should equal that message.
 * If "error" is equal to an empty string or some other falsy value,
 * then "errorMessage" should equal "An unexpected error occurred.".
 */

// WRITE YOUR ANSWER BELOW THIS LINE
// Answer Erdem Zengin
let errorMessage = error || "An unexpected error occurred.";

console.log(errorMessage || error || "An unexpected error occurred."); 
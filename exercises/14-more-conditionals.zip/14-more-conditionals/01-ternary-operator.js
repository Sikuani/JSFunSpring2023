let num = 8; // e.g.

/**
 * This is similar to an older problem.
 * Solve this problem with the ternary operator this time.
 *
 * Create a variable called "isEvenOrOdd". (Do not use var.)
 * If "num" is even, "isEvenOrOdd" should equal the string "even".
 * Otherwise, "isEvenOrOdd" should equal the string "odd".
 * Your answer should still work when "num" is a different value.
 */

// WRITE YOUR ANSWER BELOW THIS LINE
// number = 34;

// let isEvenOrOdd() {
//   return number % 2 === 0 ? "is even": 
// : number "is odd"
// }

// console.log(isEvenOrOdd);


// Respuesta Kevin Browne
const isEvenOrOdd = 8 % 2 === 0 ? "even" : "odd";
console.log(isEvenOrOdd);

